package Problem07.CreateZipArchive;

import java.io.*;
import java.util.zip.ZipOutputStream;

public class Main {
    private static final String pathSourceLines = "resources/Problem07/lines.txt";
    private static final String pathSourceWords = "resources/Problem07/words.txt";
    private static final String pathCharCounts = "resources/Problem07/count-chars.zip";
    private static final String pathDest = "resources/Problem07/text-files.zip";

    public static void main(String[] args) {
        zipFiles();
    }

    private static void zipFiles() {
        try (
                BufferedInputStream reader = new BufferedInputStream(new FileInputStream(pathSourceLines));
                ZipOutputStream zipper = new ZipOutputStream(new FileOutputStream(pathDest))
                ) {
            byte[] buffer = new byte[4096];
            while(true) {
                int readResult = reader.read(buffer);
                if (readResult == -1) {
                    break;
                }

                zipper.write(buffer);
            }
        }
        catch (IOException ioe) {
            System.out.println(ioe.toString());
        }

        try (
                BufferedInputStream reader = new BufferedInputStream(new FileInputStream(pathCharCounts));
                ZipOutputStream zipper = new ZipOutputStream(new FileOutputStream(pathDest))
        ) {
            byte[] buffer = new byte[4096];
            while(true) {
                int readResult = reader.read(buffer);
                if (readResult == -1) {
                    break;
                }

                zipper.write(buffer);
            }
        }
        catch (IOException ioe) {
            System.out.println(ioe.toString());
        }

        try (
                BufferedInputStream reader = new BufferedInputStream(new FileInputStream(pathSourceWords));
                ZipOutputStream zipper = new ZipOutputStream(new FileOutputStream(pathDest))
        ) {
            byte[] buffer = new byte[4096];
            while(true) {
                int readResult = reader.read(buffer);
                if (readResult == -1) {
                    break;
                }

                zipper.write(buffer);
            }
        }
        catch (IOException ioe) {
            System.out.println(ioe.toString());
        }
    }
}
